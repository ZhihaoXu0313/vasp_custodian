
Description
=============

The files in this directory were created for ALAMODE by T. Tadano and modified by M. Ohnishi to adjust 
auto_kappa code.

