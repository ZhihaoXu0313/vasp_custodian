#
# auto_kappa.alamode.tools
#
# Scripts in this directory are part of Alamode package developed by 
# Terumasa Tadano, and were partially modified by Masato Ohnishi.
#
# Copyright (c) 2014-2020 Terumasa Tadano
# Modified by Masato Ohnishi, 2023
#
# This file is distributed under the terms of the MIT license.
# Please see the file 'LICENCE.txt' in the root directory
# or http://opensource.org/licenses/mit-license.php for information.
#
