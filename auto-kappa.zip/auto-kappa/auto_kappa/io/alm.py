#
# alm.py
#
# This file helps to generate input scripts for Alamode.
#
# Copyright (c) 2022 Masato Ohnishi
#
# This file is distributed under the terms of the MIT license.
# Please see the file 'LICENCE.txt' in the root directory
# or http://opensource.org/licenses/mit-license.php for information.
#
#from typing import Any, Dict, List, Optional, Union
from typing import Dict
from monty.json import MSONable
import sys
import warnings
import re
import math
import numpy as np
import pymatgen

from pymatgen.io.vasp import Poscar
from ase import Atoms

from auto_kappa.units import AToBohr
from auto_kappa.structure.crystal import (
        get_formula,
        change_structure_format, 
        get_primitive_structure_spglib
        )

from ase.data import atomic_masses as atomic_masses_ase
from ase.data import atomic_numbers

import logging
logger = logging.getLogger(__name__)

try:
    import f90nml
except ImportError:
    f90nml = None

class AlmInput(MSONable, dict):
    """ Class for writing and reading alm input file.
    See the following URL for more detailed description.
    https://alamode.readthedocs.io/en/latest/almdir/inputalm.html
    
    Reference
    -------------
    pymatgen.io.shengbte.Control
    """
    required_params = {
            'always':{
                'prefix', 'mode', 'nat', 'nkd', 'kd',     # general
                'norder', 'cell', 'cutoff', 'position'    # others
                },
            'norder>=4':{
                'nbody'
                },
            'optimize':{
                'always':{
                    'dfset'
                    },
                'lmodel!=ols':{
                    'always':{
                        'fc2xml', 'conv_tol'
                        },
                    'cv!=5':{
                        'cv_minalpha', 'cv_maxalpha', 'cv_nalpha'
                        }
                    }
                }
            }
    
    ##'l1_ratio', 'l1_alpha', 
    ##'cv_maxalpha', 'cv_minalpha',
    
    general_keys = [
            'prefix',       # None, string
            'mode',         # None, string (suggest or optimize)
            'nat',          # None, integer
            'nkd',          # None, integer
            'kd',           # None, array of strings
            'tolerance',    # 1e-3, double
            'printsym',     # 0,    integer
            'fcsym_basis',  # Lattice, string
            'magmom',       # 0...0, array of double
            'noncollinear', # 0,     integer
            'periodic',     # 1 1 1, array of integers
            'nmaxsave',     # min(5, norder), integer
            'hessian',      # 0, integer
            ## >= v.1.4.x?
            'fc3_shengbte', # 0, integer
            'fc_zero_thr',  # 1.0e-12, double
            ]
    interaction_keys = {
            'norder',       # None, integer
            'nbody',        # [2,3,...,norder+1], array of integers
            }
    optimize_keys = {
            ## always
            'lmodel',         # least-squares, string
            'dfset',          # None,  string
            'ndata',          # None,  integer
            'nstart',         # 1,     integer
            'nend',           # ndata, integer
            'skip',           # None,  int-int
            'iconst',         # 11,    integer
            'rotaxis',        # None,  string
            'fc2xml',         # None,  string
            'fc3xml',         # None,  string
            'sparse',         # 0,     integer
            'sparsesolver',   # SimplicialLDLT, string
            ## for non-ols
            'maxiter',        # 10000,       integer
            'conv_tol',       # 1e-8,        double 
            'l1_ratio',       # 1.0 (LASSO), double
            'l1_alpha',       # 0.0,      double
            'cv',             # 0,        integer
            'dfset_cv',       # dfset,    string
            'ndata_cv',       # None,     integer
            'nstart_cv',      # 1,        integer
            'nend_cv',        # ndata_cv, integer
            'cv_minalpha',    # cv_maxalpha*1e-6,  double
            'cv_maxalpha',    # set automatically, double
            'cv_nalpha',      # 50,  integer
            'enet_dnorm',     # 1.0, double
            'solution_path',  # 0,   integer
            'debias_ols',     # 0,   integer
            ## for lmode == 'enet'
            'standardize',    # 1,   integer
            ## >= v.1.4.x?
            'enet_dnorm',     # 1.0, double
            'solution_path',  # 0, integer
            'debias_ols',     # 0, integer
            'stop_criterion', # 5, integer
            }
    
    def __init__(self, **kwargs):
        """
        Args
        ------
        kwargs (dict): other alm parameters. Some parameters have to be given to
            run alm.
            - mode
        """
        super().__init__()
        self.update(kwargs)
    
    @property
    def primitive(self):
        return self.get_primitive()

    def get_primitive(self):
        return get_primitive_structure_spglib(self.structure)

    @classmethod
    def from_dict(cls, alm_dict: Dict):
        """ Write a ALM input file
        """
        return cls(**alm_dict)
    
    @classmethod
    def from_structure_file(cls, filename, norder=None, **kwargs):
        """ Make ALM input parameters from a structure file
        
        Args
        -----
        filename (str): filename
            Format must be supported by pymatgen's IStructure module: POSCAR, 
            .cif. etc.
        
        """
        ## set norder
        kwargs['norder'] = norder
        
        ## set a structure
        cls.structure = Poscar.from_file(filename, check_for_POTCAR=False).structure
        alm_dict = dict(
                cls.from_structure(cls.structure, norder=norder)
                )
        
        alm_dict.update(kwargs)
        return AlmInput(**alm_dict)
    
    @classmethod
    def from_structure(cls, structure, norder=None, **kwargs):
        """ Creat ALM variables from a structure object or a structure file
        
        Args
        --------
        structure (str, pymatgen's (I)Structure, ase's Atoms, or structure file 
        
        such as POSCAR, .cif, etc.):
            If param is string (structure file), the file will be read with
            pymatgen.loadfn.
        
        guess_primitive (bool):
            If it's True, the primitive structure will be guessed with spglib.
        
        """
        alm_dict = {}
        
        ## set norder
        kwargs['norder'] = norder
        
        ## set a structure
        cls.structure = change_structure_format(
                structure, format='pmg-IStructure')
        
        ## parameters determined by the structure
        params_str = get_alamode_variables_from_structure(
                cls.structure, norder=norder)
        alm_dict.update(params_str)
        
        ## set given parameters
        alm_dict.update(kwargs)
        
        ## set prefix
        if 'prefix' not in alm_dict.keys():
            alm_dict['prefix'] = get_formula(cls.structure)
        else:
            if alm_dict['prefix'] is None:
                alm_dict['prefix'] = get_formula(cls.structure)
        
        return AlmInput(**alm_dict)
    
    def check_parameters(self):
        
        ## check parameters which a re always required
        for param in self.required_params['always']:
            _check_dict_contents(self.as_dict(), param)
        
        ## check 'norder'
        if 'norder' in self.as_dict().keys():
            _check_dict_contents(self.as_dict(), 'norder')
        
        ## Set nbody when higher-order IFCs are calculated
        try:
            if self['norder'] >= 4:
                if _check_dict_contents(
                        self.as_dict(), 'nbody', message=False) == False:
                    self['nbody'] = list(np.arange(2, self['norder']+1))
        except:
            pass
        
        ## When LMODE!=OLS
        try:
            if _lmodel_is_ols(str(self['lmodel'].lower())) == False:
                for param in self.required_params['lmodel!=ols']:
                    _check_dict_contents(self.as_dict(), param)
        except:
            pass
        
        ## check required parameters for 'mode == optimize'
        mode = self.as_dict()['mode'].lower()
        if mode == 'optimize':
            for param in self.required_params[mode]['always']:
                _check_dict_contents(self.as_dict(), param)

    def to_file(self, filename: str = None):
        """ Make ALM input file
        Args
        -------
        filename (str): ALM input file name
        """
        self.check_parameters()
        
        ## output file name
        if filename is None:
            filename = self['mode']+'.in'
        
        ## general parameters
        general_dict = _get_subdict(self, self.general_keys)
        general_nml = f90nml.Namelist({"general": general_dict})
        alm_str = str(general_nml) + "\n"
        
        ## interaction parameters
        interaction_dict = _get_subdict(self, self.interaction_keys)
        interaction_nml = f90nml.Namelist({"interaction": interaction_dict})
        alm_str += str(interaction_nml) + "\n"
        
        ### cell parameters
        lines = _write_cell(self['cell'])
        for line in lines:
            alm_str += line + "\n"

        ### cutoff parameters
        lines = _write_cutoff(self['cutoff'])
        for line in lines:
            alm_str += line + "\n"
         
        ## optimize parameters
        optimize_dict = _get_subdict(self, self.optimize_keys)
        optimize_nml = f90nml.Namelist({"optimize": optimize_dict})
        alm_str += str(optimize_nml) + "\n"
         
        ### position parameters
        lines = _write_positions(self['position'])
        for line in lines:
            alm_str += line + "\n"
        
        ## characters to be replaced
        for char in [',', '\'']:
            alm_str = alm_str.replace(char, "")
        
        ## output an ALM input file
        with open(filename, "w") as file:
            file.write(alm_str)
    
    @classmethod
    def from_file(cls, filename: str=None):
        inp_dict = _read_alamode_input(filename)
        return cls(**inp_dict)
    
    def as_dict(self):
        return dict(self)
    

## This part should be modified (rewrite).
def _get_subdict(master_dict, subkeys):
    """Get a set of keys """
    """Helper method to get a set of keys from a larger dictionary"""
    return {
            k: master_dict[k] 
            for k in subkeys 
            if k in master_dict and master_dict[k] is not None
            }

def _lmodel_is_ols(lmodel):
    if str(lmodel.lower()) in ['least-squares', 'ls', 'ols', '1']:
        return True
    else:
        return False

##
def _write_cell(cell):
    """
    Args
    ------
    cell (ndarray), shape=(3,3), unit=[Bohr]
    """
    ## set length unit
    #lengths = np.zeros(3)
    #for j in range(3):
    #    lengths[j] = np.linalg.norm(cell[j])
    #lunit = np.min(lengths)
    
    ##
    lunit = 1.0
    
    lines = []
    lines.append("&cell")
    lines.append(" %18.13f"%(lunit))
    for i in range(3):
        lines.append(" %18.13f" * 3 % tuple(cell[i]/lunit))
    lines.append("/")
    return lines

def _write_cutoff(cutoff):
    """
    Args
    -------
    cutoff (dict of array of float):
        keys are two strings connected with hyphene, e.g. 'Si-Si'
    """
    lines = []
    lines.append("&cutoff")
    for k1 in cutoff.keys():
        lines.append("    %7s  "%(k1))
        for val in cutoff[k1]:
            if val is None:
                lines[-1] += "None "
            else:
                lines[-1] += "%18.13f "%(val)
    lines.append("/")
    return lines

def _write_positions(positions):
    """
    Args
    -------
    position (ndarray), shape=(natoms, 3):
        scaled positions
    """
    lines = []
    lines.append("&position")
    for ia, pos in enumerate(positions):
        lines.append(" %3d "%(pos[0]))
        lines[-1] += " %18.13f" * 3 % tuple(pos[1:4])
    lines.append("/")
    return lines

def get_alamode_variables_from_structure(structure, norder=None):
    """ Get alm variables determined by the structure
    """
    params = {}
    
    ## number of atoms
    params['nat'] = len(structure)
    
    ## get list of chemical symbols
    sym_all = []
    for each in structure.species:
        sym_all.append(each.name)
    sym_list = sorted(set(sym_all), key=sym_all.index)
    
    ## get number of atoms for each species
    params['nkd'] = []
    params['kd'] = []
    params['nkd'] = len(sym_list)
    for sym in sym_list:
        params['kd'].append(sym)
    
    ## cell (with the unit of Bohr) 
    params['cell'] = structure.lattice.matrix * AToBohr
    
    ## set positions
    params['position'] = []
    for ia, atom in enumerate(structure):
        sym = atom.specie.name
        idx = sym_list.index(sym) + 1
        p = atom.frac_coords
        params['position'].append([idx, p[0], p[1], p[2]])
    
    ## cutoff (unit: Bohr)
    params['cutoff'] = {}
    for i1 in range(len(sym_list)):
        s1 = sym_list[i1]
        for i2 in range(i1, len(sym_list)):
            s2 = sym_list[i2]
            comb = s1+'-'+s2
            params['cutoff'][comb] = []
            if norder is not None:
                for ii in range(norder):
                    params['cutoff'][comb].append(None)
    
    return params

class AnphonInput(MSONable, dict):
    """ Class for writing and reading anphon input file.
    See the following URL for more detailed description.
    https://alamode.readthedocs.io/en/latest/anphondir/inputanphon.html
    
    Reference
    -------------
    pymatgen.io.shengbte.Control
    """
    required_params = {
            'always':{
                'prefix', 'mode', 'nkd', 'kd', 'fcsxml',    # general
                'cell', 'kpmode'
                },
            }
    general_keys = [
            'prefix',       # None, string
            'mode',         # None, string
            'nkd',          # None, integer
            'kd',           # None, Array of strings
            'mass',         # weight of elements, Array of double
            'fcsxml',       # None, string
            'fc2xml',       # None, string
            ##'fc3xml',       # None, string
            'tolerance',    # 1e-6, double
            'printsym',     # 0,    integer
            'nonanalytic',  # 0,    integer
            'na_sigma',     # 0.0,  double
            'borninfo',     # None, string
            'bornsym',      # 0,    integer
            'tmin',         # 0,    double
            'tmax',         # 1000, double
            'dt',           # 10,   double
            'emin',         # 0,    double
            'emax',         # 1000, double
            'delta_e',      # 10,   double
            'ismear',       # -1,   integer
            'epsilon',      # 10.0, double
            'bconnect',     # 0,    integer
            'classical',    # 0,    integer
            'trisym',       # 1,    integer
            'restart',      # 1 or 0, integer
            ]
    scph_keys = [
            'kmesh_interpolate', # None, Array of integers 
            'kmesh_scph',        # None, Array of integers
            'self_offdiag',      # 0,    Integer
            'tol_scph',          # 1e-10, double
            'mixalpha',          # 0.1,   double
            'maxiter',           # 1000,  integer
            'lower_temp',        # 1,     integer
            'warmstart',         # 1,     integer
            'ialgo',             # 0,     integer
            'restart_scph',      # 1, integer (0 or 1)
            ## >= 1.5.0
            'bubble',            # 0, integer (0 or 1)
            'relax_str',         # 0, integer (0, 1, 2, or 3)
            'lower_temp',        # 1, integer (0 or 1)
            'qha_scheme',        # 0, integer (0, 1, or 2)
            ]
    ## >= 1.5.0
    relax_keys = [
            'relax_algo',       # 2,     integer (1 or 2)
            'alpha_stdecent',   # 1e4,   double
            'max_str_iter',     # 100,   integer
            'add_hess_diag',    # 100.0, double
            'coord_conv_tol',   # 1e-5,  double
            'mixbeta_coord',    # 0.5,   double
            'cell_conv_tol',    # 1e-5,  double
            'mixbeta_cell',     # 0.5,   double
            'set_init_str',     # 1,     integer (1, 2, or 3)
            'cooling_u0_index', # 0,     integer (0, 1, ... 3N-1)
            'cooling_u0_thr',   # 0.001, double, Bohr
            'stat_pressure',    # 0.0,   double, GPa
            'renorm_2to1st',    # 2,     integer
            'renorm_34to1st',   # 0,     integer
            'renorm_3to2nd',    # 2,     integer
            'strain_ifc_dir',   # None,  string
            ]
    
    analysis_keys = [
            'gruneisen',      # 0, integer 
            'printevec',      # 0, integer
            'printxsf',       # 0, integer
            'printvel',       # 0, integer
            'printmsd',       # 0, integer
            'pdos',           # 0, integer
            'tdos',           # 0, integer
            'sps',            # 0, integer
            'printpr',        # 0, integer
            'kappa_coherent', # 0, integer
            'kappa_spec',     # 0, integer
            'isotope',        # 0, integer
            'isofact',        # Automatically calculated from the KD-tag
            'ucorr',          # 0, integer
            'shift_ucorr',    # [0,0,0], array of integers
            'zmode',          # 0, integer
            'anime',          # None, array of doubles 
            'anime_frames',   # 20, integer
            'anime_cellsize', # None, Array of integers
            'anime_format',   # xyz,  string
            ]
    
    all_keys = (
            general_keys + scph_keys + 
            analysis_keys + ['cell', 'kpoint', 'kpmode']
            )
    
    ### added keys for k-point 
    ##kpoint_keys = ['kpmode', 'kpoints', 'kpath', 'kpts', 'deltak']
    
    ### atomic massses which are not included in default setting of ALAMODE
    atoms_no_mass = ["Tc", "Pm", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Np", "Pu"]
    
    def __init__(self, **kwargs):
        """
        Args
        ------
        kwargs (dict): other anphon parameters. Some parameters have to be 
            given to run alm.
            - mode
        """
        super().__init__()
        self.update(kwargs)
        self._primitive = None
    
    def as_dict(self):
        return dict(self)
    
    @property
    def primitive(self):
        if self._primitive is None:
            self._primitive = self.get_primitive()
        return self._primitive
    
    def set_primitive(self, structure):
        self._primitive = structure

    def get_primitive(self):
        
        ### ver.1
        #prim = get_primitive_structure(self.structure, format='ase')
        #
        ### ver.2
        #struct_pmg = change_structure_format(self.structure, format='pmg')
        #prim = struct_pmg.get_primitive_structure()
        #
        ### ver.3
        prim = get_primitive_structure_spglib(self.structure, format='ase')
        
        return prim
    
    @classmethod
    def from_dict(cls, alm_dict: Dict):
        """ Write a ALM input file
        """
        return cls(**alm_dict)
    
    @classmethod
    def from_structure_file(cls, filename, **kwargs):
        """ Make ANPHON input parameters from a structure file
        
        Args
        -------
        filename (str): filename
            Object should be supported by pymatgen's IStructure module: POSCAR,
            .cif. etc.
        
        """
        ## get a structure
        cls.structure = Poscar.from_file(filename, check_for_POTCAR=False).structure

        ## get the primitive structure
        primitive = cls.get_primitive(cls)
        
        ## get structure parameters with the primitive structure
        anp_dict = dict(cls.from_structure(primitive))
        
        ## update parameters
        anp_dict.update(kwargs)
        
        return AnphonInput(**anp_dict)
    
    @classmethod
    def from_structure(cls, structure, **kwargs):
        """ 
        Args
        --------
        structure (structure object)
        """
        cls.structure = structure
        
        ## Get parameters determined by structure
        alm_dict = dict(AlmInput.from_structure(structure))
        
        ## Extract only available keys
        anp_dict = {}
        for k1 in alm_dict.keys():
            if k1 in cls.all_keys:
                anp_dict[k1] = alm_dict[k1]
        
        ## Parameters for k-point
        if 'kpmode' not in kwargs.keys():
            kpmode = None
        
        ## update
        anp_dict.update(kwargs)
        
        return AnphonInput(**anp_dict)
     
    
    def set_kpoint(self, **kwargs):
        """ Set suggeted k-point parameters. This module may not well written.
        
        ## kpoint_keys = ['kpmode', 'kpoints', 'kpath', 'kpts', 'deltak']
        If kpmode == 0, separated kpoints should be given
        If kpmode == 1, deltak (default: 0.01) and kpath will be set.
        If kpmode == 2, deltak (default: 0.2) and kpts will be set.
        """
        ## set kpmode
        if _check_dict_contents(
                self.as_dict(), 'kpmode', message=False) == False:
            if _check_dict_contents(kwargs, 'kpmode'):
                self['kpmode'] = kwargs['kpmode']
            else:
                ValueError(' kpmode must be given.')
        
        #exit()
        ## Check if kpmode key is set or not
        set_kpmode = False
        if 'kpmode' not in self.as_dict().keys():
            set_kpmode = True
        else:
            if self.as_dict()['kpmode'] is None:
                set_kpmode = True
        
        ## set kpmode
        if set_kpmode:
            _check_dict_contents(self.as_dict(), 'mode')
            if self['mode'].lower() == 'phonons':
                self['kpmode'] = 1
            elif self['mode'].lower() == 'scph':
                self['kpmode'] = 1
            elif self['mode'].lower() == 'rta':
                self['kpmode'] = 2
        
        ## set deltak
        if _check_dict_contents(kwargs, 'deltak', message=False):
            self['deltak'] = kwargs['deltak']
        else:
            if self['kpmode'] == 1:
                self['deltak'] = 0.01
            elif self['kpmode'] == 2:
                self['deltak'] = 0.2
        
        ## set k-points
        if self['kpmode'] == 0:
            if _check_dict_contents(kwargs, 'kpoints'):
                self['kpoints'] = kwargs['kpoints']
            else:
                self['kpoints'] = [[0,0,0]]
        elif self['kpmode'] == 1:
            if 'kpath' not in self.keys():
                msg = "\n kpath is set automatically."
                logger.info(msg)
                self['kpath'] = get_kpoint_path(
                        self.primitive, 
                        deltak=self['deltak']
                        )
        elif self['kpmode'] == 2:
            lengths = self.primitive.lattice.reciprocal_lattice.lengths
            kpts = []
            for i, leng in enumerate(lengths):
                n = max(2, int(np.ceil(leng/self['deltak'])))
                kpts.append(n)
            self['kpts'] = kpts
        
        self.update(kwargs)

    #def guess_cutoff(self):
    #    pass

    def check_parameters(self):
        
        ## check required parameters
        for param in self.required_params['always']:
            if param not in self.as_dict():
                warnings.warn(
                    "Required parameter '{}' is not specified!".format(param)
                    )
        ##
        if self['kpmode'] == 0:
            _check_dict_contents(self.as_dict(), 'kpoints')
        
        ## This part helps to set BONRINFO parameter, when nonanalytic term will
        ## be considered.
        try:
            if self['nonanalytic'] != 0:
                if _check_dict_contents(self.as_dict(), 'borninfo') == False:
                    self['borninfo'] = 'BORNINFO'
        except:
            pass
    
    def _add_mass_info(self):
        """ Add mass info """
        self["mass"] = get_mass_info(self["kd"])
        
    def _add_isofact_info(self):
        """ Add isofact info """
        
        try:
            out = get_isofact_info(self["kd"])
        except Exception:
            out = None
        
        if out is None:
            isotope_orig = self["isotope"]
            self["isotope"] = 0
            msg = "\n Modify ISOTOPE option: %d => 0." % isotope_orig
            logger.info(msg)
        else:
            self["isotope"] = 1
            self["isofact"] = out
        
    def to_file(self, filename: str = None, verbosity=0):
        """ Make ANPHON input file
        Args
        -------
        filename (str): ANPHON input file name
        """
        self.check_parameters()
        
        if verbosity > 0:
            msg = "\n Make an input script for ALAMODE : %s" % filename
            logger.info(msg)
        
        ## output file name
        if filename is None:
            if self['mode'].lower() == 'phonons':
                if self['kpmode'] == 0: 
                    filename = 'eigen.in'
                elif self['kpmode'] == 1: 
                    filename = 'band.in'
                elif self['kpmode'] == 2: 
                    filename = 'dos.in'
            else:
                filename = self['mode']+'.in'
        
        ### add mass and isotope info
        all_masses_are_given = True
        for el in self["kd"]:
            if el in self.atoms_no_mass:
                all_masses_are_given = False
        
        if all_masses_are_given == False:
            
            msg = "\n Add mass info which are not given by ALAMODE."
            logger.info(msg)
            
            self._add_mass_info()
            if "isotope" in self:
                self._add_isofact_info()
        
        ## general parameters
        general_dict = _get_subdict(self, self.general_keys)
        general_nml = f90nml.Namelist({"general": general_dict})
        anp_str = str(general_nml) + "\n"
        
        ## scph parameters
        scph_dict = _get_subdict(self, self.scph_keys)
        scph_nml = f90nml.Namelist({"scph": scph_dict})
        anp_str += str(scph_nml) + "\n"

        ## cell parameters
        lines = _write_cell(self['cell'])
        for line in lines:
            anp_str += line + "\n"
        
        ## k-point
        lines = _write_kpoint(self.as_dict())
        for line in lines:
            anp_str += line + "\n"
        
        ## analysis parameters
        analysis_dict = _get_subdict(self, self.analysis_keys)
        analysis_nml = f90nml.Namelist({"analysis": analysis_dict})
        anp_str += str(analysis_nml) + "\n"
        
        ## characters to be replaced
        for char in [',', '\'']:
            anp_str = anp_str.replace(char, "")
        
        ## output an ALM input file
        with open(filename, "w") as file:
            file.write(anp_str)
    
    @classmethod
    def from_file(cls, filename: str=None):
        inp_dict = _read_alamode_input(filename)
        return cls(**inp_dict)

def get_mass_info(elements):
    """ get mass info 
    
    Args
    =======

    elements : array of string
        name of elements
    
    Return
    ========

    array of float
    
    """
    msg = "\n Add MASS info.\n"
    mass_info = []
    for el in elements:
        num = atomic_numbers[el]
        mass = atomic_masses_ase[num]
        mass_info.append(mass)
        msg += " %s: %.5f" % (el, mass)
    logger.info(msg)
    return mass_info

def calc_g2_factor(isotopes, element=None):
    """ Calculate g2 factor for Tamura model
    
    Args
    ------
    isotopes : dictionary
        each element containes "mass" and "composition"
    
    element : string
        Name of element. If ``element`` is given, check whether the averaged 
        mass is realistic or not.
    
    Return
    ---------
    float
    
    """
    ### calc. average mass
    mave = 0.
    for num2 in isotopes:
        m_iso = isotopes[num2]['mass']
        f_iso = isotopes[num2]['composition']
        mave += m_iso * f_iso
    
    ### check average mass
    if element:
        num = atomic_numbers[element]
        mass1 = atomic_masses_ase[num]
        if abs((mave - mass1) / mass1) > 0.1:
            msg = "\n Could not obtain isotope info for %s." % (element)
            msg += "\n averaged mass: %.2f, reference mass: %.2f" % (mave, mass1)
            logger.warning(msg)
            return None
    
    ### calc. g2 factor for Tamura model
    g2 = 0.
    for num2 in isotopes:
        m_iso = isotopes[num2]["mass"]
        f_iso = isotopes[num2]['composition']
        g2 += f_iso * math.pow(1. - m_iso / mave, 2)
    return g2

def get_isofact_info(elements):
    """ Get isofact info 
    
    Args
    ------
    
    elements : array of string
    
    Return
    ------
    
    g2_factors : array, float
        array for g2 factors

    """
    from auto_kappa.io.isotopes import isotopes
    msg = "\n Get IFOFACT info."
    g2_factors = []
    for el in elements:
        num = atomic_numbers[el]
        g2_factors.append(calc_g2_factor(isotopes[num], element=el))
    
    ### output log
    msg = "\n"
    for i, el in enumerate(elements):
        msg += " %s: %.3f " % (el, g2_factors[i])
    logger.info(msg)
    return g2_factors

def _write_kpoint(params, kpoint=None):
    lines = []
    lines.append('&kpoint')
    lines.append('    %d'%(params['kpmode']))
    if params['kpmode'] == 0:
        for k in params['kpoints']:
            lines.append("    %18.13f " * 3 % tuple(k))
    elif params['kpmode'] == 1:
        for k in params['kpath']:
            lines.append("")
            for j in range(2):
                key = list(k[j].keys())[0]
                lines[-1] += "    %5s" % key
                lines[-1] += " %10.7f " * 3 % tuple(k[j][key])
            lines[-1] += " %d " % k[2]
    elif params['kpmode'] == 2:
        lines.append("    ")
        lines[-1] += "%d " * 3 % tuple(params['kpts'])

    lines.append('/')
    return lines

def _check_dict_contents(dictionary, key, message=True):
    flag = True
    if key not in dictionary:
        flag = False
    else:
        if dictionary[key] is None:
            flag = False
    ##
    if flag == False and message:
        warnings.warn(
                "Required parameter '{}' is not specified!".format(key)
                )
    return flag

def get_kpoint_path(primitive, deltak=0.01):
    """
    Args
    --------
    primitive (pymatgen's (I)Structure object):
        primitive structure
    
    Return
    --------
    kpoints (array of array of dict)
        key of dictionary is a name of symmetric point and the contained value
        is the corresponding k-point.
    """
    import seekpath
    
    if "pymatgen" not in str(type(primitive)):
        prim_pmg = change_structure_format(primitive, format='pymatgen')
    else:
        prim_pmg = primitive.copy()
    
    structure = [
            prim_pmg.lattice.matrix,
            prim_pmg.frac_coords,
            prim_pmg.atomic_numbers
            ]
    kpath = seekpath.get_path(
            structure, with_time_reversal=True, recipe='hpkot')
    
    ## extract required data
    kpoints = []
    for each in kpath['path']:
        kpoints.append([])
        k1 = np.asarray(kpath['point_coords'][each[1]])
        k0 = np.asarray(kpath['point_coords'][each[0]])
        kvec = k1 - k0 
        kleng = np.linalg.norm(kvec)
        nk = max(int(np.ceil(kleng / deltak)), 3)
        kpoints[-1] = [{each[0]: k0}, {each[1]: k1}, nk]
    return kpoints

def _read_alamode_input(filename):
    """ Read alamode input file and output a dictionary
    """
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    ## get lines for each section
    section = None
    lines_alamode = {}
    for line in lines:
        data = line.split()
        if len(data) == 0:
            continue
        if data[0][0] == "#" or data[0][0] == "/":
            continue
        if data[0][0] == '&':
            section = data[0].replace("&", "")
            lines_alamode[section] = []
            continue
        
        lines_alamode[section].append(line)
    
    ##
    params = {}
    for sec in lines_alamode:

        if sec == 'cell':
            params.update(_parse_cell_lines(lines_alamode[sec]))
        elif sec == 'kpoint':
            params.update(_parse_kpoint_lines(lines_alamode[sec]))
        elif sec == 'cutoff':
            params.update(_parse_cutoff_lines(lines_alamode[sec]))
        elif sec == 'position':
            params.update(_parse_position_lines(lines_alamode[sec]))
        else:
            params.update(_parse_normal_lines(lines_alamode[sec]))
    
    return params

def _parse_cell_lines(lines):
    params = {}
    lunit = float(lines[0].split()[0])
    vec = np.zeros((3,3))
    for i1 in range(3):
        data = lines[1+i1].split()
        for j in range(3):
            vec[i1,j] = float(data[j]) * lunit
    
    return {'cell': vec}

def _parse_cutoff_lines(lines):
    """ NEED to be modified
    """
    params = {}
    for line in lines:
        data = line.split()
        comb = data[0]
        params[comb] = []
        for ii in range(1,len(data)):
            if data[ii].lower() == 'none':
                params[comb].append(None)
            else:
                params[comb].append(float(data[ii]))
    return {'cutoff': params}

def _parse_position_lines(lines):
    positions = []
    for line in lines:
        data = line.split()
        positions.append([])
        positions[-1].append(int(data[0]))
        for j in range(3):
            positions[-1].append(float(data[1+j]))
    return {'position': positions}

def _parse_kpoint_lines(lines):
    
    params = {}
    params['kpmode'] = int(lines[0].split()[0])
    if params['kpmode'] == 0:    ## calculate phonon frequencies at given k points
        nk = len(lines) - 1
        kpoints = np.zeros((nk, 3))
        for ik in range(nk):
            data = lines[1+ik].split()
            kpoints[ik] = np.asarray(data)
        params['kpoints'] = kpoints

    elif params['kpmode'] == 1:  ## band dispersion calc
        params['kpath'] = []
        for ii in range(1, len(lines)):
            data = lines[ii].split()
            params['kpath'].append([
                    {data[0]: [float(data[1+i]) for i in range(3)]},
                    {data[4]: [float(data[5+i]) for i in range(3)]},
                    int(data[8]),
                    ])

    elif params['kpmode'] == 2:  ## uniform k grid for phonon DOS and kappa
        data = lines[1].split()
        params['kpts'] = [int(d) for d in data]
    
    return params

###
def _parse_normal_lines(lines):
    """ Read lines with normal formal such as "key = val", 
    "key = val1, val2, ...".
    """
    params = {}
    for line in lines:
        data = line.split()
        ll = ""
        for i in range(len(data)-2):
            if i != 0:
                ll += " "
            ll += data[2+i]
        val = proc_val(data[0], ll)
        params[data[0]] = val
    return params

def proc_val(key, val):
    
    str_keys = (
            ## shared
            'prefix',        # None, string
            'mode',          # None, string (suggest or optimize)
            'fc2xml',         # None,  string
            'fc3xml',         # None,  string
            ## alm
            'kd',            # None, array of strings
            'fcsym_basis',   # Lattice, string
            'lmodel',         # least-squares, string
            'dfset',          # None,  string
            'rotaxis',        # None,  string
            'dfset_cv',       # dfset,    string
            'sparsesolver',   # SimplicialLDLT, string
            'skip',           # None,  int-int
            ## anphon
            'fcsxml',        # None, string
            'borninfo',      # None, string
            'anime_format',  # xyz,  string
            )
    
    int_keys = (
            ## shared
            'nkd',          # None, integer
            'norder',
            'printsym',       # 0,    integer
            ## alm
            'nonanalytic',    # 0,    integer
            'bornsym',        # 0,    integer
            'ismear',         # -1,   integer
            'bconnect',       # 0,    integer
            'classical',      # 0,    integer
            'trisym',         # 1,    integer
            'restart',        # 1 or 0, integer
            'self_offdiag',   # 0,    Integer
            'maxiter',        # 1000,  integer
            'lower_temp',     # 1,     integer
            'warmstart',      # 1,     integer
            'ialgo',          # 0,     integer
            'restart_scph',   # 1 or 0, integer
            'gruneisen',      # 0, integer 
            'printevec',      # 0, integer
            'printxsf',       # 0, integer
            'printvel',       # 0, integer
            'printmsd',       # 0, integer
            'pdos',           # 0, integer
            'tdos',           # 0, integer
            'sps',            # 0, integer
            'printpr',        # 0, integer
            'kappa_coherent', # 0, integer
            'kappa_spec',     # 0, integer
            'isotope',        # 0, integer
            'ucorr',          # 0, integer
            'zmode',          # 0, integer
            'anime_frames',   # 20, integer
            ## anphon
            'nat',          # None, integer
            'noncollinear', # 0,     integer
            'nmaxsave',     # min(5, norder), integer
            'hessian',      # 0, integer
            'fc3_shengbte', # 0, integer
            'norder',       # None, integer
            'ndata',          # None,  integer
            'nstart',         # 1,     integer
            'nend',           # ndata, integer
            'iconst',         # 11,    integer
            'sparse',         # 0,     integer
            'maxiter',        # 10000,       integer
            'cv',             # 0,        integer
            'ndata_cv',       # None,     integer
            'nstart_cv',      # 1,        integer
            'nend_cv',        # ndata_cv, integer
            'cv_nalpha',      # 50,  integer
            'solution_path',  # 0,   integer
            'debias_ols',     # 0,   integer
            'standardize',    # 1,   integer
            'solution_path',  # 0, integer
            'debias_ols',     # 0, integer
            'stop_criterion', # 5, integer
            )
    
    double_keys = (
            ## shared
            'tolerance',    # 1e-6, double
            ## alm
            'na_sigma',     # 0.0,  double
            'tmin',         # 0,    double
            'tmax',         # 1000, double
            'dt',           # 10,   double
            'emin',         # 0,    double
            'emax',         # 1000, double
            'delta_e',      # 10,   double
            'epsilon',      # 10.0, double
            'tol_scph',          # 1e-10, double
            'mixalpha',          # 0.1,   double
            ## anphon
            'fc_zero_thr',  # 1.0e-12, double
            'conv_tol',       # 1e-8,        double 
            'l1_ratio',       # 1.0 (LASSO), double
            'l1_alpha',       # 0.0,      double
            'cv_minalpha',    # cv_maxalpha*1e-6,  double
            'cv_maxalpha',    # set automatically, double
            'enet_dnorm',     # 1.0, double
            'enet_dnorm',     # 1.0, double
            )
            
    strarray_keys = (
            'kd',           # None, Array of strings
            )
    
    intarray_keys = (
            ## sahre
            'nbody',             # array of integers
            ## alm
            'kmesh_interpolate', # None, Array of integers 
            'kmesh_scph',        # None, Array of integers
            'shift_ucorr',       # [0,0,0], array of integers
            'anime_cellsize',    # None, Array of integers
            ## anphon
            'periodic',          # 1 1 1, array of integers
            )

    doublearray_keys = (
            ## alm
            'mass',         # weight of elements, Array of double
            'isofact',        # Automatically calculated from the KD-tag
            'anime',          # None, array of doubles 
            ## anphon
            'magmom',       # 0...0, array of double
            )
    
    ##
    if key in str_keys:
        return str(val)

    elif key in int_keys:
        return int(val)

    elif key in double_keys:
        return float(val)

    elif key in strarray_keys:
        return [str(d) for d in val.split()]
    
    elif key in intarray_keys:
        v = [int(d) for d in val.split()]
        return [int(d) for d in val.split()]

    elif key in doublearray_keys:
        return [float(d) for d in val.split()]
    
    else:
        warnings.warn(" Error: %s is not defined." % key)
        exit()


#def write_alamode_input(mode: None, structure=None, prefix="prefix", 
#        dfset=None, **args):
#    """ Write an input script of Alamode
#    
#    Args
#    -----
#    mode : string, default=None
#        "suggest", "optimize", "phonons"
#
#    """
#    modes_alm = ['suggest', 'optimize']
#    modes_anphon = ['phonons', 'rta', 'scph']
#    
#    if mode in modes_alm:
#        inp = AlmInput.from_structure(
#                structure,
#                mode=mode,
#                )
#    
#
