auto-kappa
=============

.. toctree::
    :maxdepth: 2
    :numbered: 2

    test/modules    

..
    auto-kappa/modules
    auto-kappa/io/modules
    auto-kappa/structure/modules
    auto-kappa/alamode_tools/modules
    auto-kappa/plot/modules
    auto-kappa/plot/alamode/modules


