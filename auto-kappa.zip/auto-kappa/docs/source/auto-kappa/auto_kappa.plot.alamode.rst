auto\_kappa.plot.alamode package
================================

Submodules
----------

auto\_kappa.plot.alamode.band module
------------------------------------

.. automodule:: auto_kappa.plot.alamode.band
   :members:
   :undoc-members:
   :show-inheritance:

auto\_kappa.plot.alamode.dos module
-----------------------------------

.. automodule:: auto_kappa.plot.alamode.dos
   :members:
   :undoc-members:
   :show-inheritance:

auto\_kappa.plot.alamode.participation module
---------------------------------------------

.. automodule:: auto_kappa.plot.alamode.participation
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: auto_kappa.plot.alamode
   :members:
   :undoc-members:
   :show-inheritance:
