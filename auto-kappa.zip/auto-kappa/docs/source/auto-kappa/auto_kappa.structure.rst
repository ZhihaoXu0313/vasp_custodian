auto\_kappa.structure package
=============================

Submodules
----------

auto\_kappa.structure.cells module
----------------------------------

.. automodule:: auto_kappa.structure.cells
   :members:
   :undoc-members:
   :show-inheritance:

auto\_kappa.structure.crystal module
------------------------------------

.. automodule:: auto_kappa.structure.crystal
   :members:
   :undoc-members:
   :show-inheritance:

auto\_kappa.structure.supercell module
--------------------------------------

.. automodule:: auto_kappa.structure.supercell
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: auto_kappa.structure
   :members:
   :undoc-members:
   :show-inheritance:
