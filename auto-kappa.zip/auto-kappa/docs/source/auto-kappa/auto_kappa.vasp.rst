auto\_kappa.vasp package
========================

Submodules
----------

auto\_kappa.vasp.relax module
-----------------------------

.. automodule:: auto_kappa.vasp.relax
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: auto_kappa.vasp
   :members:
   :undoc-members:
   :show-inheritance:
