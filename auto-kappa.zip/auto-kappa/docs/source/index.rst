.. auto-kappa
    Written by M. Ohnishi
    September 13, 2022.

Auto-KAPPA
============

.. toctree::
    :maxdepth: 2
    :numbered: 2
    :glob:

    installation
    parameters
    tutorial/index
    
    auto-kappa/modules


