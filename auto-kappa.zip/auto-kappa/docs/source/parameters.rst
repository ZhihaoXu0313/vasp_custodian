===================
Default parameters
===================

VASP
=====

VASP parameters used for `Phonondb <http://phonondb.mtl.kyoto-u.ac.jp>`_
are adopted while a few parameters are modified by 
`Custodian <https://materialsproject.github.io/custodian/>`_
when the calculation is not finished.

.. csv-table:: Default parameters for VASP
    :file: ./files/default_params.csv
    :header-rows: 1
    :align: center

Alamode
========


Output directories
===================



