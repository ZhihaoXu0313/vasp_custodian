python mksuggest.py  
python mkoptimize.py  
python mkband.py  
python mkkappa.py

