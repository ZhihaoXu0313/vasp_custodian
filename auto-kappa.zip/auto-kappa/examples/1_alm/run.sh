#
# A very simple example to check if alm of Alamode command works properly.
#
alm suggest.in > suggest.log

