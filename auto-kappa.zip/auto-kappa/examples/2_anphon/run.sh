#
# A very simple example to check if anphon of Alamode command works properly.
#
anphon band.in > band.log

