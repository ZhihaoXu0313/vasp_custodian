python setup.py sdist

pip install dist/auto_kappa-0.3.tar.gz

rm -r dist

